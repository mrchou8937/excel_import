<?php
//连接数据库
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "test";
// 创建连接
$conn = @new mysqli($servername, $username, $password, $dbname);
// 检测连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 允许上传的图文件后缀
$allowedExts = array("xls", "xlsx", "csv");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);     // 获取文件后缀名
$filePath = '';
if (($_FILES["file"]["size"] < 2048000)   // 小于 2 MB
    && in_array($extension, $allowedExts)
) {
    if ($_FILES["file"]["error"] > 0) {
        echo "错误：: " . $_FILES["file"]["error"] . "<br>";
    } else {
        // 判断当期目录下的 upload 目录是否存在该文件
        // 如果没有 upload 目录，你需要创建它，upload 目录权限为 777
        if (file_exists("upload/" . $_FILES["file"]["name"])) {
            echo $_FILES["file"]["name"] . " 文件已经存在。 ";
        } else {
            //重命名文件名
            $filename = date('YmdHis' . rand(1000, 9999)) . '.xls';
            // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下
            move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $filename);
            $filePath = "upload/" . $filename;
        }
    }
} else {
    echo "非法的文件格式";
    die();
}

//引入PHPExcel类
require_once dirname(__FILE__) . '/PHPExcel/PHPExcel.php';
//实例化PHPExcel类
$objPHPExcel = new PHPExcel();
//默认用excel2007读取excel，若格式不对，则用之前的版本进行读取
$PHPReader = new PHPExcel_Reader_Excel2007();
if (!$PHPReader->canRead($filePath)) {
    $PHPReader = new PHPExcel_Reader_Excel5();
    if (!$PHPReader->canRead($filePath)) {
        echo 'no Excel';
        return;
    }
}
//读取Excel文件
$PHPExcel = $PHPReader->load($filePath);
//读取excel文件中的第一个工作表
$sheet = $PHPExcel->getSheet(0);
//取得最大的列号
$allColumn = $sheet->getHighestColumn();
//取得最大的行号
$allRow = $sheet->getHighestRow();
//从第3行开始插入,第2行是列名
for ($currentRow = 3; $currentRow <= $allRow; $currentRow++) {
    //获取A列的值
    $name = $PHPExcel->getActiveSheet()->getCell("A" . $currentRow)->getValue();
    //获取B列的值
    $sex = $PHPExcel->getActiveSheet()->getCell("B" . $currentRow)->getValue();
    //获取C列的值
    $age = $PHPExcel->getActiveSheet()->getCell("C" . $currentRow)->getValue();
    //获取D列的值
    $address = $PHPExcel->getActiveSheet()->getCell("D" . $currentRow)->getValue();
    if ($sex === '男') {
        $sex = 1;
    } else {
        $sex = 2;
    }
    //插入数据
    $sql = "INSERT INTO user (name, sex, age, address) VALUES ('$name','$sex','$age','$address')";
    if ($conn->query($sql) === TRUE) {
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
echo '导入成功!';
//关闭数据库连接
$conn->close();

?>